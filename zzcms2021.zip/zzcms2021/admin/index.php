<?php
define('checkadminlogin',1);
include("admin.php");

if (opensite=='No' ){
echo "<script>location.href='siteconfig.php#SiteOpen'</script>";
}	
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="renderer" content=webkit>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<title>管理员后台</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<style>
html,body{margin: 0px;height:100%}/*必须设height值，否则最外层DIV设值无效*/
</style>
<script>
var status = 1;
function switchSysBar(){
     if (1 == window.status){
		  window.status = 0;
          switchPoint.innerHTML = '<img src="image/manage_left.gif">';
          document.getElementById("FrmTitle").style.display="none"
     }else{
		  window.status = 1;
          switchPoint.innerHTML = '<img src="image/manage_right.gif">';
          document.getElementById("FrmTitle").style.display=""
     }
}
</script>
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="top">
  <tr>
    <td width="200" style="padding-left:5px"><div class="admin_logo"><a href="index.php">后台管理</a></div></td>
    <td style="white-space:nowrap; overflow:hidden; text-overflow:ellipsis">
 <?php $rs=query("select groupname from zzcms_admingroup where id=(select groupid from zzcms_admin where admin='".$admin."')");
	  $row= fetch_array($rs);
	  echo "您好<b>".$admin."</b>(" .$row["groupname"].")";
	  ?>
        [ <a href="/index.php" target="_top">首页</a> | <a href="loginout.php" target="_top">退出</a> 
        ] [ <a href="http://www.zzcms.net/zixun/class/22" target="_blank">帮助</a> ]	
</td>
</tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" height="92%">
  <tr>
    <td align="middle" valign="top" width="200" id="FrmTitle" height="100%">
	<iframe frameborder="0" id="frmleft" name="frmleft" src="left.php" style="height:100%; visibility: inherit;width: 200px;" allowtransparency="true"></iframe>
	</td>
	  <td width="18" height="100%"  valign="middle"> 
        <div onClick="switchSysBar()"> <span class="navpoint" id="switchPoint" title="关闭/打开左栏"><img src="image/manage_right.gif" alt="" /></span> 
        </div>
	</td>
	<td valign="top" height="100%">
<iframe frameborder="0" id="frmright" name="frmright" scrolling="yes" src="right.php" style="height:100%; visibility: inherit; width:100%; z-index:1;"></iframe>
	</td>
  </tr>
</table>
</body>
</html>