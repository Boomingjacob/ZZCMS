<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<?php
include("admin.php");

$FileExt="xls";
header("Content-type:application/vnd.ms-excel;");
header("Content-Disposition:filename=user_".date('Y-m-d H:i:s').".xls");

$sql="select * from zzcms_user where passed=1 order by id desc";
$rs=query($sql);
$table="<table width=100% cellspacing=0 cellpadding=0 border=1>";
$table=$table."<tr>";

$table=$table."<td align=center  bgcolor=#dddddd><b>用户名</b></td>";
$table=$table."<td align=center  bgcolor=#dddddd><b>密码</b></td>";
$table=$table."<td align=center  bgcolor=#dddddd><b>电话</b></td>";
$table=$table."<td align=center  bgcolor=#dddddd><b>Emai</b></td>";
$table=$table."<td align=center  bgcolor=#dddddd><b>公司名</b></td>";
$table=$table."<td align=center  bgcolor=#dddddd><b>联系人姓名</b></td>";

$table=$table."</tr>";
while ($row=fetch_array($rs)){
$table=$table."<tr>";

$table=$table."<td>".$row['username']."</td>";
$table=$table."<td>".$row['password']."</td>";
$table=$table."<td>".$row['phone']."</td>";
$table=$table."<td>".$row['email']."</td>";
$table=$table."<td>".$row['comane']."</td>";
$table=$table."<td>".$row['somane'].$row['city']."</td>";

$table=$table."</tr>";
}
$table=$table."</table>";
echo $table;

?>