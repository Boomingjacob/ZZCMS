<?php
include("admin.php");
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="admintitle">清理HTML页</div>
<div class="border px14">
<?php
checkadminisdo("siteconfig");
$dir="../html/".siteskin."/daili";
del_dirandfile($dir);	
?>
</div>
</body>
</html>