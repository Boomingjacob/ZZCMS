<?php
include("admin.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css">
<script>
function ConfirmClear(){
   if(confirm("初始化数据库后将不能恢复！确定初始化么？"))
     return true;
   else
     return false;	 
}
function CheckAll(form){
  for (var i=0;i<form.elements.length;i++){
    var e = form.elements[i];
    if (e.Name != "chkAll")
       e.checked = form.chkAll.checked;
    }
}
</script>
</head>
<body>
<div class="admintitle">初始化数据库</div>
<?php
if (!isset($_POST["action"])) {
?>

      <form name="form1" method="post" action="" onSubmit="return ConfirmClear();">
      
            <div class="border">
				<?php 
$rs = query("SHOW TABLES"); 
$i=1;
while($row = fetch_array($rs)) { 
	if ($row[0]=='zzcms_admin' || $row[0]=='zzcms_admingroup'){
	echo "<li style='padding:0 0 0 20px'><label><span style='padding:0 5px'>".$i."</span>".$row[0]." (注：管理员相关表，初始化后不能登录)</label></li>"; 
	}else{
	echo "<li><label><input name='table[]' type='checkbox'  value='".$row[0]."'><span style='padding:0 5px'>".$i."</span>".$row[0]; 
	
	$sqlN="select * from ".$row[0]."";
	$rsN=query($sqlN);
	$rowN=num_rows($rsN);
	echo " (共<span class='px14'> ".$rowN." </span>条记录)</span>";
	echo "</label></li>";
	}
	$i++;
}

			?>		
			 </div>
 <div class="border" style="clear:both">
			 <label><input name="chkAll" type="checkbox" id="chkAll" onClick="CheckAll(this.form)" value="checkbox">全选/取消全选</label>
              <input name="Submit24" type="submit" class="buttons" value="初始化"> 
              <input name="action" type="hidden" id="action" value="clear"> </td>
         
        </div>
      </form>
<?php
}else{
checkadminisdo("siteconfig");
?>
<div class="border">
<?php
if(!empty($_POST['table'])){
    for($i=0; $i<count($_POST['table']);$i++){
	query("truncate ".trim($_POST['table'][$i])."");
	echo $table[$i]."表已被初始化<br>"; 
    }
	echo "<a href='javascript:history.back()'>返回</a>";	
}else{
showmsg('操作失败！至少要选中一条信息。');
}
?>
</div>
<?php
}
?>
</body>
</html>