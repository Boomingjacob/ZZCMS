﻿<?php
require("../inc/conn.php");
include("../inc/top2.php");
include("../inc/bottom.php");

function bigclass($channel){
$str="";
$n=1;
switch ($channel){
	case "zhanhui":$sql="select classname,classid from zzcms_zhanhuiclass  order by xuhao";
	break;
	case "zixun":$sql="select classid,classname from zzcms_zixunclass where isshow=1 and parentid=0 order by xuhao asc";
	break;
	case "special":$sql="select classid,classname from zzcms_specialclass where isshow=1 and parentid=0 order by xuhao asc";
	break;
	case "job":$sql="select classname,classid from zzcms_jobclass where parentid=0 order by xuhao";
	break;
	case "company":$sql="select classid,classname from zzcms_userclass order by xuhao asc";
	break;
	default:$sql="select classname,classid,classzm from zzcms_zhaoshangclass where parentid=0 order by xuhao";
	}
$rs=query($sql);
$row=num_rows($rs);
if (!$row){
$str="暂无分类";
}else{
	while ($row=fetch_array($rs)){
	$str=$str."<li>";
	switch ($channel){
	case "zhaoshang":$str=$str."<a href='".getpageurl_class("zsclass",$row["classzm"])."'>".$row["classname"]."</a>";
	break;
	case "daili":$str=$str."<a href='".getpageurl2("daili",$row["classzm"],"")."'>".$row["classname"]."</a>";
	break;
	case "pinpai":$str=$str."<a href='".getpageurl2("pinpai",$row["classzm"],"")."'>".$row["classname"]."</a>";
	break;
	case "zhanhui":$str=$str."<a href='".getpageurl2("zhanhui",$row["classid"],"")."'>".$row["classname"]."</a>";
	break;
	case "zixun":$str=$str."<a href='".getpageurl_class("zixun",$row["classid"])."'>".$row["classname"]."</a>";
	break;
	case "job":$str=$str."<a href='".getpageurl2("job",$row["classid"],"")."'>".$row["classname"]."</a>";
	break;
	case "special":$str=$str."<a href='".getpageurl_class("special",$row["classid"])."'>".$row["classname"]."</a>";
	break;
	case "company":$str=$str."<a href='".getpageurl2("company",$row["classid"],"")."'>".$row["classname"]."</a>";
	break;
	}
	
	$str=$str."</li>\n";
	$n=$n+1;		
	}
}
return $str;
}

$fp="../template/".$siteskin."/sitemap.htm";
if (file_exists($fp)==false){WriteErrMsg($fp.'模板文件不存在');exit;}
$f = fopen($fp,'r');
$strout = fread($f,filesize($fp));
fclose($f);

$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#pagetitle}",sitetitle,$strout);
$strout=str_replace("{#pagekeywords}",sitekeyword,$strout);
$strout=str_replace("{#pagedescription}",sitedescription,$strout);
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);
$strout=str_replace("{#zhaoshang}",bigclass("zhaoshang"),$strout);
$strout=str_replace("{#daili}",bigclass("daili"),$strout);
$strout=str_replace("{#pinpai}",bigclass("pinpai"),$strout);
$strout=str_replace("{#zhanhui}",bigclass("zhanhui"),$strout);
$strout=str_replace("{#zixun}",bigclass("zixun"),$strout);
$strout=str_replace("{#job}",bigclass("job"),$strout);
$strout=str_replace("{#special}",bigclass("special"),$strout);
$strout=str_replace("{#company}",bigclass("company"),$strout);
echo  $strout;
?>