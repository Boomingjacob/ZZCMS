<?php
$_CACHE['hosts'] = '';
