function easytabs(active) {
currenttab=active;
	for (i=1; i <= tabcount; i++){
	document.getElementById(tablink_idname+i).className='tab'+i;document.getElementById(tabcontent_idname+i).style.display = 'none';
	}
document.getElementById(tablink_idname+active).className='tab'+active+' tabactive';document.getElementById(tabcontent_idname+active).style.display = 'block';
}//'tab'+active+' tabactive �������������CSS

var timer; counter=0; var totaltabs=tabcount;
function start_autochange(){
counter=counter+1;timer=setTimeout("start_autochange()",1000);
	if (counter == changespeed+1) {
	currenttab++;
		if (currenttab>totaltabs) {currenttab=1}
		easytabs(currenttab);restart_autochange();
	}
}
function restart_autochange(){
clearTimeout(timer);counter=0;start_autochange();
}
function stop_autochange(){
clearTimeout(timer);counter=0;
}

window.onload=function(){
easytabs(1)
if (autochangemenu!=0){start_autochange();}
}