<?php
ob_start();//打开缓冲区label.php中有用
include("../inc/conn.php");
include("../inc/top_index.php");
include("../inc/bottom.php");
include("../label.php");

if (isset($_REQUEST["province"])){$province=$_REQUEST["province"];}else{$province="";}
$province_hz=trim(province_zm2hz($province));//省份名从记事本中的数组中读出的，得加trim去除去两端空白内容，否则无法从数据库中读取到内容

if (isset($_REQUEST["city"])){$city=$_REQUEST["city"];}else{$city=$province_hz;}
$city_hz=trim(city_zm2hz($city));

$fp="../template/".$siteskin."/area_show.htm";
if (file_exists($fp)==false){WriteErrMsg($fp.'模板文件不存在');exit;}
$f = fopen($fp,'r');
$strout = fread($f,filesize($fp));
fclose($f);
$strout=str_replace("{#siteskin}",$siteskin,$strout) ;
$strout=str_replace("{#sitename}",sitename,$strout) ;
$strout=str_replace("{#siteurl}",siteurl,$strout) ;
$strout=str_replace("{#pagetitle}",$city_hz.sitetitle,$strout);
$strout=str_replace("{#pagekeywords}",$province_hz.sitekeyword,$strout);
$strout=str_replace("{#pagedescription}",$province_hz.sitedescription,$strout);
$strout=str_replace("{#province}",$province_hz,$strout) ;
$strout=str_replace("{#city}",$city_hz,$strout) ;
$strout=str_replace("{#sitebottom}",sitebottom(),$strout);
$strout=str_replace("{#sitetop}",sitetop(),$strout);

if (flyadisopen=="Yes") {
$strout=str_replace("{#flyad}",Showflyad("首页","漂浮广告"),$strout);
}else{
$strout=str_replace("{#flyad}","",$strout);
}
if (duilianadisopen=="Yes"){
$strout=str_replace("{#duilianad}",showduilianad("首页","对联广告左侧","对联广告右侧"),$strout);
}else{
$strout=str_replace("{#duilianad}","",$strout);
}

$strout=showlabel($strout);

if ($city<>'') {
$city_hz=str_replace("市",'',$city_hz);
$strout=str_replace('{#province_site}',$city_hz.'站',$strout) ;
}elseif ($province<>'') {
$strout=str_replace('{#province_site}',$province_hz.'站',$strout) ;
}else{
$strout=str_replace('{#province_site}','',$strout);
}

echo  $strout;
?>